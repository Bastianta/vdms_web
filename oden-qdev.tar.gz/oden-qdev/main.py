from flask import request
import globalVar

APP_NAME = 'SKELETON'

# Get library to common lib (staging / production)
# def getLibrary(lib_id, app_id="common", type="python") : 
#    import requests 
#    if type == "python" : 
#        urltype = "get_py" 
#    elif type == "js" : 
#        urltype = "get_js"
#    result = requests.get(f'{globalVar.URL_LIB}/{urltype}?app_id={app_id}&lib_id={lib_id}', headers={"PRODUCTION":"Y"})
#    if result.status_code == 200 : 
#        try : 
#            rsData = result.text 
#            exec(rsData, globals()) 
#        except : 
#            raise Exception("Check requirements yang diperlukan / jalankan debug source") 
#    else : 
#        raise Exception("Tidak bisa melakukan koneksi ke server standard library")


# Get library development oden
def getLibrary(param) :
    try :
        with open(f"common/{param}.py", "r") as file:
            exec(file.read(), globals())        
    except :
        raise Exception("Check requirements yang diperlukan / jalankan debug source")
    
getLibrary("satlog")
getLibrary("satgetdatetime")
getLibrary("saturl")
getLibrary("satssowebclientnd")
getLibrary("satconnectserver2RO")
getLibrary("satconnectserver2")
getLibrary("lib_errorCodePG")
getLibrary("utilities_v1.2")
getLibrary("base")
getLibrary("satconnectredis")
getLibrary("satconnectbucket")
getLibrary("oden_v1.2")
        
class CustomOden(Oden):

    def authenticate(self):
        return True, {
            'nik': '0000000001',
            'attributes': {
                'company_code': '01',
                'name': 'Developer Oden',
                "company": "SAT",
            },
        }
    
    def getMenu(self):
        import staticOdenMenu
        userAttributes = staticOdenMenu.kwargs
        userAttributes.update({"list_menu":staticOdenMenu.list_menu})
        return True, userAttributes["list_menu"][1]["data"]["menu_id"]
    
    def authorize(self, menuId):
        import staticOdenMenu
        userAttributes = staticOdenMenu.kwargs
        return True, userAttributes['access_menu']
    
    def view(self, menuId, html):
        return html
        
CustomOden.name = "Oden Development"
CustomOden(host='0.0.0.0', port=8002, debug=True)
