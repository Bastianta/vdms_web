# SETTING MODUL APLIKASI
MD5 = 'Y'
BASE64 = 'Y'
BZ2 = 'Y'

LOGIN = 'WEB'
MINIMAL_TIME_DIFFERENCE = -60
SALTED_HASH_EXPIRES = 900
LOG_NAME = 'SSO_'+str(LOGIN)
# URL_SERVER = "https://stag-dot-sso-web-sat-prd.et.r.appspot.com"
URL_SERVER = "https://stag-asl.sat.co.id"
URL_SERVER_VERIFY = "http://10.176.42.34"
PRODUCTION = "N" #--> localhost 'N' / app engine 'Y'
PRODUCTION_ODEN = "N"

# SIGNATURE KEY
"""
local       : app id untuk client web
key         : signature key untuk masing-masing app id
continueUrl : value yang hanya dimilik client web
* catatan *
    - APP_ID disini case sensitive
"""
APP_ID = ""
SIGNATURE_KEY = ""
CONTINUE_URL = "http://34.101.215.169:5001"

# =================================================== END OF SSO =================================================

import sys
#MULTILANGUAGE
MULTILANGUAGE = False
ALWAYS_UPDATE_MULTILANGUAGE = "N"
MENU_TYPE = 'NAVBAR' #NAVBAR/SIDEBAR

connRO = None
if PRODUCTION == "N":
    URL = 'http://localhost:8080'
    URL_LIB = "http://34.101.215.169:6000" #development
    # URL_LIB = "http://10.176.39.45" #production (harus req whitelist ke common lib (pic ivan RnS))
    URL_CDN = '/static/oden-stable/v.1.2'
    # URL_CDN = "https://hocdnoden0201.sat.co.id/js-dev"   #opsional untuk file di hocdn bucket
    URL_REPORT = "https://10.176.42.10/cgi-bin/fw_report.py"
    HOST_REDIS = "127.0.0.1"
    PORT_REDIS = 6379
    PASSWORD_REDIS = ""
    TIME_EXPIRED_REDIS = 900
    DEFAULT_BUCKET = "sat-oden-upload"
    SATBUCKET_DESTINATION_LOCAL_FOLDER = ""
    DEFAULT_LOCAL = "/home/userName" #ganti userName dengan nama user pada direktori CE
    DB_NAME = 'oden'
elif PRODUCTION == "Y":
    URL = '' #ini diisi DNS cloud run / dns requestan ke IT Opr
    # URL_LIB = "http://34.101.215.169:6000" #development
    URL_LIB = "http://10.176.39.45" #production (harus req whitelist ke common lib (pic ivan RnS))
    # URL_CDN = "https://hocdnoden0201.sat.co.id/js"        
    URL_CDN = "https://hocdnoden0201.sat.co.id/js-dev"  #uptodate now
    URL_REPORT = "https://horeporthc0201.sat.co.id/cgi-bin/fw_report.py"
    HOST_REDIS = '127.0.0.1'
    PORT_REDIS = 6379
    PASSWORD_REDIS = None
    TIME_EXPIRED_REDIS = 900
    DEFAULT_BUCKET = "sat-oden-upload"
    DEFAULT_LOCAL = "/home/userName" #ganti userName dengan nama user pada direktori CE
    SATBUCKET_DESTINATION_LOCAL_FOLDER = ""
    DB_NAME = 'oden' #diisi alias pada connection.cfg
else:
    print('konfigurasi globalVar.PRODUCTION tidak sesuai')
    sys.exit()


