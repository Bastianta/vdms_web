# EMPLOYEE_DASHBOARD - Custom Bootstrap Dashboard

## Overview
A modern, interactive dashboard built with Bootstrap 5 showcasing real-time analytics and insights for DPLK period management.

## Features

### 📊 Dashboard Components

1. **Statistics Cards** (4 cards with gradient backgrounds)
   - Total Employees
   - Active Periods
   - Pending Processes
   - Average Duration (in days)

2. **Interactive Charts**
   - **Process Distribution** - Doughnut chart showing process flag distribution
   - **Yearly Trend** - Line chart showing processes over years

3. **Recent Activities**
   - Real-time list of recent period activities
   - Status badges (Completed, Active, In Progress)
   - Date ranges and process flags

### 🎨 Design Features
- **Gradient backgrounds** with smooth hover effects
- **Responsive layout** - works on all screen sizes
- **Auto-refresh** - updates every 30 seconds
- **Loading animations** - smooth data loading experience
- **Bootstrap Icons** - modern iconography
- **Chart.js integration** - interactive data visualization

### 🔧 Technical Stack
- **Frontend**: Bootstrap 5.3, jQuery, Chart.js
- **Backend**: Python with @exposeApi functions
- **Database**: PostgreSQL (dmhr schema)
- **API Communication**: Standardized Oden API calls

## API Functions

### 1. getDashboardStats_EMPLOYEE_DASHBOARD
Returns overall statistics:
```json
{
  "total_employees": 3,
  "active_periods": 2,
  "pending_processes": 1,
  "avg_duration_days": 182
}
```

### 2. getRecentActivities_EMPLOYEE_DASHBOARD
Returns recent activities with status:
```json
[
  {
    "year": "2025",
    "process_flag": "PROCESS_1",
    "start_date": "01 Jan 2025",
    "end_date": "30 Jun 2025",
    "status": "Completed"
  }
]
```

### 3. getProcessDistribution_EMPLOYEE_DASHBOARD
Returns data for doughnut chart:
```json
[
  {"label": "PROCESS_1", "value": 2},
  {"label": "PROCESS_2", "value": 2}
]
```

### 4. getYearlyTrend_EMPLOYEE_DASHBOARD
Returns data for line chart:
```json
[
  {"year": "2024", "total_processes": 2},
  {"year": "2025", "total_processes": 2}
]
```

## Files Structure

```
application/
  └── EMPLOYEE_DASHBOARD.py    # Backend API functions

template/
  └── EMPLOYEE_DASHBOARD.html  # Bootstrap dashboard UI
```

## Access

**URL**: `http://34.128.84.194:8001`

**Menu**: Navigate to **EMPLOYEE_DASHBOARD**

## Customization Points

### Change Colors
Edit gradient backgrounds in `<style>` section:
```css
.stat-card { 
  background: linear-gradient(135deg, #YOUR_COLOR1 0%, #YOUR_COLOR2 100%); 
}
```

### Modify Auto-Refresh Interval
Change the interval in JavaScript (default: 30 seconds):
```javascript
setInterval(function() {
    loadStats();
    loadActivities();
}, 30000); // Change this value (in milliseconds)
```

### Add More Charts
1. Create new API function in Python with `@exposeApi`
2. Add canvas element in HTML
3. Create Chart.js instance in JavaScript

## Browser Compatibility
- ✅ Chrome/Edge (latest)
- ✅ Firefox (latest)
- ✅ Safari (latest)
- ✅ Mobile browsers

## Performance
- Lightweight (< 100KB total assets)
- Fast loading with CDN resources
- Efficient SQL queries with aggregations
- Minimal API calls with auto-refresh

## Future Enhancements
- [ ] Export data to Excel/PDF
- [ ] Date range filters
- [ ] User-specific dashboards
- [ ] Real-time notifications
- [ ] Dark mode toggle
- [ ] More chart types (bar, radar, etc.)
