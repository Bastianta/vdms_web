# MST_HRA_12 - DPLK Period Master Data Form

## Form Overview
Simple master-detail form for managing DPLK (Dana Pensiun Lembaga Keuangan) period data.

## Database Structure

### Parent Table: dmhr.ms_dplk_periode_head
- **mdph_tahun** (timestamp, PK) - Year
- Audit columns: mdph_create_user, mdph_update_user, mdph_create_date, mdph_update_date

### Child Table: dmhr.ms_dplk_periode_det
- **mdpd_tahun** (timestamp, PK) - Year
- **mdpd_flag_proses** (varchar(50), PK) - Process Flag
- **mdpd_start_date** (timestamp, PK) - Start Date
- **mdpd_end_date** (timestamp) - End Date
- Audit columns: mdpd_create_user, mdpd_update_user, mdpd_create_date, mdpd_update_date

## Form Structure

### Parent Block: DPLK_PERIODE_HEAD (FormLayout)
- **mdphtahun** - Year selector

### Child Block: DPLK_PERIODE_DET (DataGridLayout)
- **mdpdtahun** - Year
- **mdpdflagproses** - Process Flag
- **mdpdstartdate** - Start Date
- **mdpdenddate** - End Date

## Files Created

1. **application/MST_HRA_12.py** - Python backend
   - Block classes with short descriptor MHRA12
   - Item classes for all business columns
   - Record validation
   - newInstance functions for both blocks

2. **static/application/MST_HRA_12.js** - JavaScript frontend
   - Form and datagrid elements
   - Validation rules
   - Parent-child relationship configuration

## Key Features

- ✅ Master-detail relationship (1 parent, 1 child)
- ✅ Composite primary key in detail table (3 columns)
- ✅ Date validation (end date must be after start date)
- ✅ Auto-loading child data when parent record selected
- ✅ Audit columns excluded from Item classes

## How to Access

1. Start the application: `python main.py`
2. Open browser: `http://<your-ip>:8001`
3. Navigate to menu: **MST_HRA_12**

## Testing Checklist

- [ ] Can add new year in header
- [ ] Can add multiple detail records per year
- [ ] Child records load automatically when selecting parent
- [ ] Date validation works (end date > start date)
- [ ] Can update existing records
- [ ] Can delete records
- [ ] Composite primary key prevents duplicates

## Notes

- Form uses short descriptor **MHRA12** for all Python classes
- All itemIds are lowercase
- Audit columns managed by database triggers
- Child block automatically filters by parent's year (mdphtahun)
