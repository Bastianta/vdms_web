-- MST_HRA_12 - DPLK Period Master Data
-- Database: PostgreSQL
-- Schema: dmhr

-- Create schema if not exists
CREATE SCHEMA IF NOT EXISTS dmhr;

-- Drop tables if exist (for clean setup)
DROP TABLE IF EXISTS dmhr.ms_dplk_periode_det CASCADE;
DROP TABLE IF EXISTS dmhr.ms_dplk_periode_head CASCADE;

-- Parent Table: DPLK Period Header
CREATE TABLE dmhr.ms_dplk_periode_head (
    mdph_tahun timestamp NOT NULL,
    mdph_create_user varchar(30) NULL,
    mdph_update_user varchar(30) NULL,
    mdph_create_date timestamp NULL DEFAULT CURRENT_TIMESTAMP,
    mdph_update_date timestamp NULL,
    CONSTRAINT ms_dplk_periode_head_pkey PRIMARY KEY (mdph_tahun)
);

-- Child Table: DPLK Period Detail
CREATE TABLE dmhr.ms_dplk_periode_det (
    mdpd_tahun timestamp NOT NULL,
    mdpd_flag_proses varchar(50) NOT NULL,
    mdpd_start_date timestamp NOT NULL,
    mdpd_end_date timestamp NULL,
    mdpd_create_user varchar(30) NULL,
    mdpd_update_user varchar(30) NULL,
    mdpd_create_date timestamp NULL DEFAULT CURRENT_TIMESTAMP,
    mdpd_update_date timestamp NULL,
    CONSTRAINT ms_dplk_periode_det_pkey PRIMARY KEY (mdpd_tahun, mdpd_flag_proses, mdpd_start_date),
    CONSTRAINT ms_dplk_periode_det_fkey FOREIGN KEY (mdpd_tahun) REFERENCES dmhr.ms_dplk_periode_head(mdph_tahun) ON DELETE CASCADE
);

-- Create indexes for better performance
CREATE INDEX idx_ms_dplk_periode_det_tahun ON dmhr.ms_dplk_periode_det(mdpd_tahun);
CREATE INDEX idx_ms_dplk_periode_det_dates ON dmhr.ms_dplk_periode_det(mdpd_start_date, mdpd_end_date);

-- Insert sample data
INSERT INTO dmhr.ms_dplk_periode_head (mdph_tahun, mdph_create_user) 
VALUES 
    ('2024-01-01'::timestamp, '2209116'),
    ('2025-01-01'::timestamp, '2209116'),
    ('2026-01-01'::timestamp, '2209116');

INSERT INTO dmhr.ms_dplk_periode_det (mdpd_tahun, mdpd_flag_proses, mdpd_start_date, mdpd_end_date, mdpd_create_user)
VALUES
    ('2024-01-01'::timestamp, 'PROCESS_1', '2024-01-01'::timestamp, '2024-06-30'::timestamp, '2209116'),
    ('2024-01-01'::timestamp, 'PROCESS_2', '2024-07-01'::timestamp, '2024-12-31'::timestamp, '2209116'),
    ('2025-01-01'::timestamp, 'PROCESS_1', '2025-01-01'::timestamp, '2025-06-30'::timestamp, '2209116'),
    ('2025-01-01'::timestamp, 'PROCESS_2', '2025-07-01'::timestamp, '2025-12-31'::timestamp, '2209116');

-- Grant permissions (adjust as needed)
-- GRANT ALL ON dmhr.ms_dplk_periode_head TO your_user;
-- GRANT ALL ON dmhr.ms_dplk_periode_det TO your_user;

-- Verify data
SELECT 'Header Records:' as info, COUNT(*) as count FROM dmhr.ms_dplk_periode_head
UNION ALL
SELECT 'Detail Records:' as info, COUNT(*) as count FROM dmhr.ms_dplk_periode_det;
