# Custom Oden Framework Development Guide

## Overview
Custom Oden extends the standard Oden Framework to support custom HTML templates while maintaining the same Python backend structure and security model. The Oden v1.2 library handles all routing, execution, and framework functionality automatically.

## Key Capabilities

### 1. Custom HTML Templates
- **Template Location**: `templates/` directory (instead of `static/application/`)
- **Python Backend**: Same `application/` directory structure as standard Oden
- **API Integration**: Standardized API calls with same security model
- **Frontend Freedom**: Use any CSS framework (Tailwind, ShadCN, Bootstrap, etc.)
- **Automatic Routing**: Oden v1.2 library handles all routing and execution

### 2. Built-in Framework Features
- **Unified Routing**: `/` endpoint with `type` parameter handling (built into Oden v1.2)
- **Template Serving**: GET requests serve HTML templates automatically
- **API Processing**: POST requests with `type: "API"` execute Python functions
- **Security**: Same authentication and authorization as standard Oden

## Project Structure

```
project/
├── main.py                    # Simple Oden v1.2 initialization
├── globalVar.py              # Configuration (same as standard Oden)
├── templates/                 # Custom HTML templates
│   ├── FORM_NAME.html       # Template files (uppercase naming)
│   └── DASHBOARD.html
├── application/             # Python backend files (same as standard Oden)
│   ├── FORM_NAME.py        # Python logic with @exposeApi functions
│   └── DASHBOARD.py
└── static/                  # Static assets (CSS, JS, images)
    └── assets/
```

## Implementation Guide

### 1. Main Application Setup (Minimal)

```python
# main.py - Oden v1.2 handles everything
def getLibrary(libraryId):
    with open('common/%s.py' % libraryId, 'r') as file:
        exec(file.read(), globals())

# Load required libraries
getLibrary("oden_v1.2")
getLibrary("utilities_v1.2")
getLibrary("base")

# Oden v1.2 automatically handles:
# - Route setup (/)
# - Template serving
# - API execution
# - Security
# - Session management

Oden.name = "Custom View Application"
Oden(host='0.0.0.0', port=5000, debug=True)
```

### 2. Configuration (Same as Standard Oden)

```python
# globalVar.py
PRODUCTION = "N"
URL_LIB = 'http://10.176.42.24:6000'
URL_CDN = 'https://hocdnoden0201.sat.co.id/staging/v.1.2'

MULTILANGUAGE = True
ALWAYS_UPDATE_MULTILANGUAGE = "Y"
MENU_TYPE = 'NAVBAR'

```

### 3. Standardized API Communication (Built-in)

```javascript
// Frontend API Function (works with any framework)
// Oden v1.2 automatically handles the routing
function callAPI(menuId, apiName, data = {}) {
    return $.ajax({
        url: '/',  // Oden v1.2 handles this route automatically
        type: 'POST',
        contentType: 'application/json',
        data: JSON.stringify({
            "type": "API",
            "menuId": menuId,
            "data": data,
            "apiName": apiName
        }),
        dataType: 'json'
    });
}
```

### 4. Python Backend Functions (Same as Standard Oden)

```python
# application/EMPLOYEE_DASHBOARD.py
# Exactly the same as standard Oden - no changes needed
@exposeApi
def getDashboardData_EMPLOYEE_DASHBOARD():
    """
    Standard Oden API function with @exposeApi decorator
    Oden v1.2 automatically discovers and executes this function
    """
    ajaxData = request.json.get("data")
    employeeId = ajaxData.get("employeeId")
    
    # Your business logic here (same as standard Oden)
    dashboard_data = {
        "employeeName": "John Doe",
        "monthlySalary": 5500,
        "daysPresent": 22,
        "performance": 92
    }
    
    return {
        "status": True,
        "data": dashboard_data,
        "msg": "Success"
    }

#add also an execVcount variable with empty string, this is 
execVcount = ""
```

## Frontend Framework Examples

### 1. Tailwind CSS Dashboard
```html
<!-- templates/EMPLOYEE_DASHBOARD.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body class="bg-gray-100">
    <div class="container mx-auto p-6">
        <!-- Stats Cards with Loading Animation -->
        <div class="grid grid-cols-4 gap-6">
            <div class="bg-white p-6 rounded-lg shadow">
                <p class="text-sm text-gray-600">Monthly Salary</p>
                <p class="text-2xl font-semibold" id="salary">
                    <div class="animate-pulse bg-gray-300 h-6 w-20 rounded"></div>
                </p>
            </div>
        </div>
    </div>
    
    <script>
        // Load dashboard data
        callAPI("EMPLOYEE_DASHBOARD", "getDashboardData_EMPLOYEE_DASHBOARD", {
            "employeeId": "EMP001"
        }).done(function(result) {
            $('#salary').text('$' + result.data.monthlySalary.toLocaleString());
        });
    </script>
</body>
</html>
```

### 2. Bootstrap Components
```html
<!-- templates/USER_PROFILE.html -->
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h5>User Profile</h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" class="form-control" id="fullName">
                        </div>
                        <button class="btn btn-primary" onclick="saveProfile()">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        function saveProfile() {
            callAPI("USER_PROFILE", "saveUserProfile_USER_PROFILE", {
                "fullName": $('#fullName').val()
            }).done(function(result) {
                alert('Profile saved!');
            });
        }
    </script>
</body>
</html>
```

## Security Features

### 1. Same Security Model as Standard Oden
- **@exposeApi Decorator**: Required for all API functions
- **Request Validation**: Same validation patterns as standard Oden
- **Session Management**: Can integrate with Oden's session system
- **Authentication**: Can use Oden's authentication mechanisms

### 2. API Function Security
```python
@exposeApi
def secureFunction_MENU_ID():
    """
    Same security patterns as standard Oden
    """
    # Validate user permissions
    # Check session data
    # Validate input data
    ajaxData = request.json.get("data")
    
    # Your secure business logic
    return {"status": True, "data": result}
```

## Advanced Features

### 1. Multiple Template Support
```python
# Route to different templates
@app.route('/<template_name>')
def serve_template(template_name):
    return render_template(f'{template_name.upper()}.html')
```

### 2. Static Asset Serving
```python
# Serve CSS, JS, images
@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)
```

### 3. File Upload Support
```python
@exposeApi
def uploadFile_MENU_ID():
    files = request.files.getlist('files')
    # Handle file uploads same as standard Oden
    return {"status": True, "msg": "Files uploaded"}
```

## Development Workflow

### 1. Create Template
1. Design HTML template in `templates/FORM_NAME.html`
2. Use any CSS framework or custom styling
3. Implement AJAX calls using standardized `callAPI()` function

### 2. Create Python Backend
1. Create `application/FORM_NAME.py`
2. Implement functions with `@exposeApi` decorator
3. Follow standard Oden patterns for data handling
4. Add a empty string variable named execVcount (THIS IS MANDATORY!!!)

### 3. Add in the main.py 
Everytime you create a new custom view, add the conditional if to the menuId and redirect it to the corresponding menuId
This is mandatory so the navbar/sidebar can go to the right menu with right type of CUSTOM_VIEW
```python
    def view(self,menuId,html):
        if(menuId == "DASHBOARD"):
            return redirect(f"/?type=CUSTOM_VIEW&menuId={menuId}")
        else:
            return html
```

### 4. Test Integration
1. Start Flask application
2. Access template via browser
3. Verify API calls work correctly

## Migration Path

### From Standard Oden to Custom Oden
1. **Keep Python Files**: No changes needed in `application/` directory
2. **Create Templates**: Convert JavaScript forms to HTML templates
3. **Update API Calls**: Replace Oden's restapi with `callAPI()` function
4. **Test Functionality**: Ensure all features work correctly

### From Custom Oden to Standard Oden
1. **Keep Python Files**: Backend remains compatible
2. **Create JavaScript Forms**: Convert templates to Oden JavaScript forms
3. **Update API Calls**: Use Oden's restapi functions
4. **Deploy**: Standard Oden deployment process

## Best Practices

### 1. Template Organization
- Use uppercase naming for templates (match Python files)
- Organize templates by functionality
- Keep templates focused and modular

### 2. API Design
- Follow standard Oden API naming conventions
- Use consistent error handling
- Implement proper validation

### 3. Security
- Always use `@exposeApi` decorator
- Validate all input data
- Implement proper authentication checks
- Follow Oden security patterns

### 4. Performance
- Minimize API calls
- Use loading states for better UX
- Implement proper error handling
- Cache static assets

## Project Documentation Requirements

### Mandatory Project Guide Creation

**IMPORTANT**: Every Custom Oden project MUST include a comprehensive project requirements document (`PROJECT_REQUIREMENTS.md` or `FORM_REQUIREMENTS.md`) that contains:

#### 1. Project Structure Documentation
- Complete file structure with descriptions
- Database schema requirements
- Configuration settings needed

#### 2. Form-by-Form Specifications
Each form in the project must be documented with:

**Form Overview**:
- Purpose and functionality description
- User interface components required
- Business logic requirements

**Database Requirements**:
```sql
-- Complete table structures
-- Indexes needed
-- Views or stored procedures
-- Sample data if applicable
```

**API Functions Required**:
```python
# List all @exposeApi functions needed
# Input parameters with examples
# Expected output formats
# Error handling requirements
```

**Frontend Features Required**:
- UI components checklist
- Interactive features needed
- Customization points for developers
- JavaScript functions to implement

**Implementation Priority**:
- Phase-based development approach
- Dependencies between forms
- Critical vs optional features

#### 3. Template Structure

**For Single Form Projects**:
```markdown
# PROJECT_NAME - Requirements

## Form: FORM_NAME
### Database Requirements
### API Functions Required  
### Frontend Features Required
### Customization Points
```

**For Multi-Form Projects**:
```markdown
# PROJECT_NAME - Form Requirements

## FORM 1: FORM_NAME_1
[Complete specifications]

## FORM 2: FORM_NAME_2  
[Complete specifications]

## Implementation Priority
### Phase 1: [Core forms]
### Phase 2: [Secondary forms]
```

#### 4. Developer Guidance Sections

**Customization Points**:
```javascript
// TODO: Replace with your database columns
// TODO: Customize action buttons based on business rules
// TODO: Add your custom filters
```

**Configuration Examples**:
```python
# Production vs Development settings
# Database connection examples
# Menu structure templates
```

**Security Requirements**:
- Authentication patterns
- Authorization rules
- Input validation examples
- Audit logging requirements

#### 5. Implementation Checklist

Each project guide must include:
- [ ] Database setup tasks
- [ ] API implementation tasks  
- [ ] Frontend development tasks
- [ ] Testing requirements
- [ ] Deployment steps

### When to Create Project Documentation

1. **Before Development**: Create comprehensive requirements document
2. **During Development**: Update with implementation details and customizations
3. **After Completion**: Finalize with deployment and maintenance instructions

### Documentation Benefits

- **For Developers**: Clear implementation roadmap and requirements
- **For Users**: Understanding of system capabilities and customization options  
- **For Maintenance**: Complete reference for future updates and troubleshooting
- **For Training**: Comprehensive guide for new team members

### Example Documentation Files

See the sample `FORM_REQUIREMENTS.md` created for the Human Capital Online Test project as a template for documenting Custom Oden projects.

## Conclusion

Custom Oden provides the flexibility of modern frontend frameworks while maintaining the robust backend capabilities and security model of the standard Oden Framework. This approach allows developers to create sophisticated user interfaces while leveraging existing Oden infrastructure and patterns.

**Remember**: Always create comprehensive project documentation before starting development to ensure clear requirements, proper implementation, and maintainable code.