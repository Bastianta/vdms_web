---
inclusion: always
---

# Oden Framework Features Guide

This steering file documents advanced Oden features that span both Python and JavaScript.

---

## 1. SUB_PARENT — Splitting One Record Across Multiple Tabs

### Purpose

When a single database table has too many columns to fit in one form view, use `SUB_PARENT` to split fields across multiple tabs (via verticalMultiView) while keeping them as **one logical record**.

### Key Rules

- All `SUB_PARENT` blocks share the **same database table** as the `PARENT` block
- The framework **merges** SUB_PARENT data into the parent before INSERT/UPDATE/DELETE
- On SELECT, the framework **distributes** parent record fields to each SUB_PARENT block

### JavaScript Configuration

```javascript
var winConfigForm = {
    // PARENT block — main tab
    "PS_KARYAWAN": {
        "ELEMENT": ["psnik", "psnama", "pskdstore", ...],
        "PRIMARY_KEY": ["psnik"],
        "RELATION_KEY": [],
        "BLOCK_TYPE": ["FORM", "PARENT"],
        ...
    },
    // SUB_PARENT block — additional tab (same table)
    "PS_MASTER": {
        "ELEMENT": ["pstmplahir", "pstgllahir", "psjeniskelamin", ...],
        "PRIMARY_KEY": [],              // No PK — it's the parent's PK
        "RELATION_KEY": ["psnik"],      // References parent's PK
        "BLOCK_TYPE": ["FORM", "SUB_PARENT"],
        "LOV_API": { ... }
    },
    // Another SUB_PARENT block — another tab (same table)
    "PS_HUMAN_RESOURCE_DEPARTMENT": {
        "ELEMENT": ["psjabatan", "psrekeningbank", ...],
        "PRIMARY_KEY": [],
        "RELATION_KEY": ["psnik"],
        "BLOCK_TYPE": ["FORM", "SUB_PARENT"],
        "LOV_API": { ... }
    }
}
```

### JavaScript Block Creation & Layout

```javascript
// Each SUB_PARENT gets its own form.SimpleForm
let blockPS_MASTER = form.SimpleForm("PS_MASTER", elementPS_MASTER, rulesPS_MASTER)
let blockPS_HRD = form.SimpleForm("PS_HUMAN_RESOURCE_DEPARTMENT", elementPS_HRD, rulesPS_HRD)

// Use verticalMultiView to create tabs
let tab0 = verticalMultiView.element("MASTER", blockPS_MASTER)
let tab1 = verticalMultiView.element("HRD", blockPS_HRD)
let multiView = verticalMultiView.view([tab0, tab1])

// Layout: parent form + multiview tabs
let content = layout.baseLayout([blockPS_KARYAWAN, multiView])
```

### Python Backend — CRITICAL Differences

**1. NO separate block class for SUB_PARENT blocks.** All items go into the PARENT block class:

```python
class TRSHRA50_CPs_Karyawan(FormLayout):
    def __init__(self, blockId):
        super().__init__(blockId)
        self.databaseTable = "dmhr.ps_karyawan"  # ONE table for all
        self.nonVisibleItems = [["ps_create_user","createUser"], ["ps_update_user","updateUser"]]
        self.noDbItems = []
```

**2. ALL items (parent + all SUB_PARENT) go into the parent's `setListObj()`:**

```python
TRSHRA50_vBlockPs_Karyawan = TRSHRA50_CPs_Karyawan("PS_KARYAWAN")
TRSHRA50_vBlockPs_Karyawan.setListObj([
    # Items visually in PS_KARYAWAN (PARENT tab)
    TRSHRA50_Cps_nik, TRSHRA50_Cps_nama, TRSHRA50_Cps_kd_store,
    # Items visually in PS_MASTER (SUB_PARENT tab)
    TRSHRA50_Cps_tmp_lahir, TRSHRA50_Cps_tgl_lahir, TRSHRA50_Cps_jenis_kelamin,
    # Items visually in PS_HUMAN_RESOURCE_DEPARTMENT (SUB_PARENT tab)
    TRSHRA50_Cps_jabatan, TRSHRA50_Cps_rekening_bank,
    # ... all items from all SUB_PARENT blocks
])
TRSHRA50_vBlockPs_Karyawan.ObjRecord = TRSHRA50_CRecordPs_Karyawan
```

**3. SUB_PARENT blocks are NOT appended to the form in `execVcount`:**

```python
execVcount = """
session["loggedId"] = kwargs
TRSHRA50_vContainer = Container()
TRSHRA50_vForm = Form()
TRSHRA50_vContainer.update(TRSHRA50_vForm)

# Only PARENT block is created and appended
TRSHRA50_vBlockPs_Karyawan = TRSHRA50_CPs_Karyawan("PS_KARYAWAN")
TRSHRA50_vBlockPs_Karyawan.setListObj([...all items...])
TRSHRA50_vBlockPs_Karyawan.ObjRecord = TRSHRA50_CRecordPs_Karyawan

# CHILD blocks are appended
TRSHRA50_vBlockPendidikan = TRSHRA50_CPendidikan("PS_PENDIDIKAN_FORMAL")
TRSHRA50_vBlockPendidikan.relationBlock = TRSHRA50_vBlockPs_Karyawan
...

TRSHRA50_vContainer.getForm().dataBlocks = []
TRSHRA50_vContainer.getForm().append(TRSHRA50_vBlockPs_Karyawan)  # PARENT only
TRSHRA50_vContainer.getForm().append(TRSHRA50_vBlockPendidikan)   # CHILD blocks
# NO append for SUB_PARENT blocks!
"""
```

**4. newInstance functions ARE required for SUB_PARENT blocks:**

```python
def newInstance_HRA_50_PS_KARYAWAN(**kwargs):
    newInstance = {"status": True, "data": {}, "msg": ""}
    return newInstance

def newInstance_HRA_50_PS_MASTER(**kwargs):
    newInstance = {"status": True, "data": {}, "msg": ""}
    return newInstance

def newInstance_HRA_50_PS_HUMAN_RESOURCE_DEPARTMENT(**kwargs):
    newInstance = {"status": True, "data": {}, "msg": ""}
    return newInstance
```

### Summary Table

| Aspect | PARENT | SUB_PARENT | CHILD |
|--------|--------|------------|-------|
| Database table | Main table | **Same as PARENT** | Different table |
| JS BLOCK_TYPE | `["FORM", "PARENT"]` | `["FORM", "SUB_PARENT"]` | `["DATAGRID", "CHILD"]` |
| JS PRIMARY_KEY | Has PK | `[]` empty | Has own PK |
| JS RELATION_KEY | `[]` empty | Parent's PK | Parent's PK |
| Python block class | Has own class | **NO class** | Has own class |
| Python setListObj | Contains ALL items (parent + SUB_PARENT) | N/A | Contains own items |
| Python execVcount append | Appended | **NOT appended** | Appended |
| Python relationBlock | N/A | N/A | Set to parent |
| Python newInstance | Required | Required | Required |
| Records | Single record | Same single record | Multiple records |
| Block creation (JS) | `form.SimpleForm(...)` | `form.SimpleForm(...)` | `datatable.SimpleDatatable(...)` |

### When to Use SUB_PARENT

- Table has 30+ columns that won't fit in one form view
- You want to organize fields into logical tabs (Personal, HR, Finance, etc.)
- All fields belong to the **same database record**

