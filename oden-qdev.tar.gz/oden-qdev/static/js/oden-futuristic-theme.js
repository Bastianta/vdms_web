/**
 * Oden Futuristic Theme Controller
 * Red Primary, Yellow Secondary Color Scheme
 */

class OdenFuturisticTheme {
    constructor() {
        this.init();
    }

    init() {
        this.loadThemeCSS();
        this.setupAnimations();
        this.setupInteractiveElements();
        this.setupResponsiveFeatures();
    }

    loadThemeCSS() {
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = '/static/css/oden-futuristic-theme.css';
        document.head.appendChild(link);
    }

    setupAnimations() {
        // Add fade-in animation to all webix views
        webix.event(document, "DOMContentLoaded", () => {
            setTimeout(() => {
                const views = document.querySelectorAll('.webix_view');
                views.forEach((view, index) => {
                    setTimeout(() => {
                        view.classList.add('fade-in');
                    }, index * 100);
                });
            }, 500);
        });

        // Add slide-in animation to sidebar items
        webix.event(document, "click", (e) => {
            if (e.target.closest('.webix_list_item')) {
                e.target.closest('.webix_list_item').classList.add('slide-in');
            }
        });
    }

    setupInteractiveElements() {
        // Enhanced button hover effects
        webix.event(document, "mouseover", (e) => {
            if (e.target.closest('.webix_button')) {
                const button = e.target.closest('.webix_button');
                button.style.transform = 'translateY(-2px) scale(1.02)';
                button.classList.add('glow-red');
            }
        });

        webix.event(document, "mouseout", (e) => {
            if (e.target.closest('.webix_button')) {
                const button = e.target.closest('.webix_button');
                button.style.transform = 'translateY(0) scale(1)';
                button.classList.remove('glow-red');
            }
        });

        // Enhanced form field focus effects
        webix.event(document, "focus", (e) => {
            if (e.target.matches('.webix_inp_text, .webix_inp_static')) {
                e.target.parentElement.classList.add('glow-yellow');
                this.createFocusRipple(e.target);
            }
        }, true);

        webix.event(document, "blur", (e) => {
            if (e.target.matches('.webix_inp_text, .webix_inp_static')) {
                e.target.parentElement.classList.remove('glow-yellow');
            }
        }, true);
    }

    createFocusRipple(element) {
        const ripple = document.createElement('div');
        ripple.className = 'focus-ripple';
        ripple.style.cssText = `
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            background: rgba(251, 191, 36, 0.3);
            border-radius: 50%;
            transform: translate(-50%, -50%);
            animation: ripple 0.6s ease-out;
            pointer-events: none;
            z-index: 1000;
        `;

        element.parentElement.style.position = 'relative';
        element.parentElement.appendChild(ripple);

        setTimeout(() => {
            ripple.remove();
        }, 600);
    }

    setupResponsiveFeatures() {
        // Mobile menu toggle
        const createMobileToggle = () => {
            const toggle = document.createElement('button');
            toggle.className = 'mobile-menu-toggle';
            toggle.innerHTML = '☰';
            toggle.style.cssText = `
                display: none;
                position: fixed;
                top: 20px;
                left: 20px;
                z-index: 1001;
                background: var(--primary-red);
                color: white;
                border: none;
                border-radius: 8px;
                padding: 12px;
                font-size: 18px;
                cursor: pointer;
                box-shadow: 0 4px 12px rgba(220, 38, 38, 0.3);
            `;

            toggle.addEventListener('click', () => {
                const sidebar = document.querySelector('.webix_sidebar');
                if (sidebar) {
                    sidebar.classList.toggle('active');
                }
            });

            document.body.appendChild(toggle);

            // Show toggle on mobile
            const mediaQuery = window.matchMedia('(max-width: 768px)');
            const handleMediaQuery = (e) => {
                toggle.style.display = e.matches ? 'block' : 'none';
            };
            mediaQuery.addListener(handleMediaQuery);
            handleMediaQuery(mediaQuery);
        };

        createMobileToggle();
    }

    // Theme customization methods
    setPrimaryColor(color) {
        document.documentElement.style.setProperty('--primary-red', color);
    }

    setSecondaryColor(color) {
        document.documentElement.style.setProperty('--secondary-yellow', color);
    }

    // Status indicator methods
    addStatusIndicator(element, status) {
        element.classList.remove('status-active', 'status-warning', 'status-error');
        element.classList.add(`status-${status}`);
    }

    // Loading animation
    showLoading(container) {
        const loader = document.createElement('div');
        loader.className = 'futuristic-loader';
        loader.innerHTML = `
            <div class="loader-ring"></div>
            <div class="loader-text">Loading...</div>
        `;
        loader.style.cssText = `
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(31, 41, 55, 0.9);
            backdrop-filter: blur(5px);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            z-index: 1000;
        `;

        const style = document.createElement('style');
        style.textContent = `
            .loader-ring {
                width: 60px;
                height: 60px;
                border: 4px solid rgba(251, 191, 36, 0.3);
                border-top: 4px solid var(--secondary-yellow);
                border-radius: 50%;
                animation: spin 1s linear infinite;
            }
            .loader-text {
                color: var(--secondary-yellow);
                font-weight: 600;
                margin-top: 16px;
                animation: pulse 1.5s ease-in-out infinite;
            }
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
            @keyframes pulse {
                0%, 100% { opacity: 1; }
                50% { opacity: 0.5; }
            }
            @keyframes ripple {
                0% { width: 0; height: 0; opacity: 1; }
                100% { width: 100px; height: 100px; opacity: 0; }
            }
        `;
        document.head.appendChild(style);

        container.style.position = 'relative';
        container.appendChild(loader);

        return loader;
    }

    hideLoading(loader) {
        if (loader && loader.parentElement) {
            loader.remove();
        }
    }

    // Notification system
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `futuristic-notification notification-${type}`;
        notification.textContent = message;
        
        const colors = {
            success: 'var(--success-green)',
            warning: 'var(--warning-orange)',
            error: 'var(--primary-red)',
            info: 'var(--secondary-yellow)'
        };

        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${colors[type]};
            color: ${type === 'info' ? 'var(--dark-bg)' : 'white'};
            padding: 16px 24px;
            border-radius: 8px;
            font-weight: 600;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
            z-index: 1002;
            animation: slideInRight 0.3s ease-out;
            max-width: 300px;
        `;

        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideInRight {
                from { transform: translateX(100%); opacity: 0; }
                to { transform: translateX(0); opacity: 1; }
            }
        `;
        document.head.appendChild(style);

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.style.animation = 'slideInRight 0.3s ease-out reverse';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
}

// Initialize theme when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.odenTheme = new OdenFuturisticTheme();
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = OdenFuturisticTheme;
}
